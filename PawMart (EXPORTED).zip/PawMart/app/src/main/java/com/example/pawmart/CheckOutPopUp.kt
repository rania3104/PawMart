package com.example.pawmart

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class CheckOutPopUp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_check_out_pop_up)
    }
}