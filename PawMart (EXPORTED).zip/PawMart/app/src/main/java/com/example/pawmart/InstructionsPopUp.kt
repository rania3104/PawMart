package com.example.pawmart

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class InstructionsPopUp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_instructions_pop_up)
    }
}